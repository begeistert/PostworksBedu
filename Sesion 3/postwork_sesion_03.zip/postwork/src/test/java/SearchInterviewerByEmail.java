
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class SearchInterviewerByEmail {
        static String existingInterviewerName = "First";
        static String existingInterviewerLastName = "User";
        static String existingInterviewerEmail =  "first@email.com";

        @BeforeEach
        public void setUp() throws Exception {
            Interviewer.data = new ArrayList<>();


        }
        @Test
        public void searchInterviewerByEmail() {

            Interviewer interviewer = new Interviewer(
                    existingInterviewerName,
                    existingInterviewerLastName,
                    existingInterviewerEmail,
                    true
            );
            //System.out.println(interviewer.toString());
            Interviewer interviewerReceived = Interviewer.getByEmail("Interviewer Email");

            assertEquals("first@email.com",interviewer.email,"Email no existe")   ;

        }
    @Test
    public void searchInterviewerByInvalidEmail() {

        Interviewer interviewer = new Interviewer(
                existingInterviewerName,
                existingInterviewerLastName,
                existingInterviewerEmail,
                true
        );
        //System.out.println(interviewer.toString());
        Interviewer interviewerReceived = Interviewer.getByEmail("Interviewer Email");

        assertNull(interviewerReceived,"Email no encontrado");   ;

    }
}
