import java.io.*;
import java.util.ArrayList;

public class Discipline {

    static ArrayList<Discipline> data;

    int id;
    String name;
    String slug;
    String descripcion;

    public Discipline(){}

    public Discipline(
            String name,
            String slug,
            String descripcion
    ) {
        this.id = data != null ? data.size() + 1 : 1;
        this.name = name;
        this.slug = slug;
        this.descripcion = descripcion;

    }

    public Discipline add() {
        data.add(this);
        Discipline.saveDataToFile();
        return this;
    }

    public void delete() throws Exception{

        data.remove(this);
        this.saveDataToFile();

    }

    public void save(
            String name,
            String slug,
            String descripcion
    ) {
        try {
            this.delete();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }

        if (!name.equals(""))
            this.name = name;

        if (!slug.equals(""))
            this.slug = slug;

        if (!descripcion.equals(""))
            this.descripcion = descripcion;


        data.add(this);
    }

    public static void saveDataToFile() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("./discipline");
            ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);

            outputStream.writeObject(Interviewer.data);

            outputStream.close();
            fileOutputStream.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public static void loadDataFromFile() {
        try {
            FileInputStream fileInputStream = new FileInputStream("./discipline");
            ObjectInputStream inputStream = new ObjectInputStream(fileInputStream);

            ArrayList<Interviewer> fileData = (ArrayList<Interviewer>) inputStream.readObject();

            Interviewer.data.clear();
            Interviewer.data.addAll(fileData);

            inputStream.close();
            fileInputStream.close();
        } catch (Exception e) {
            if (!e.getMessage().contains("No such file or directory"))
                e.printStackTrace();
        }
    }

}
