import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class DisciplineTest {
    @BeforeEach
    void setUp() {
        Discipline.data = new ArrayList<>();
        Discipline.data.add(new Discipline("disciplina 1",
                "disciplina-1",
                "Disciplina 1"));
    }
    @Test
    void add() {
        Discipline discipline = new Discipline("disciplina 2",
                "disciplina-2",
                "Disciplina 2");

        int previousSize = Discipline.data.size();
        discipline.add();
        int newSize = Discipline.data.size();

        assertEquals(1, newSize - previousSize);

    }

    @Test
    void delete() {
        Discipline discipline = new Discipline("disciplina 3",
                "disciplina-3",
                "Disciplina 3");

        int previousSize = Discipline.data.size();
        discipline.add();
        try {
            discipline.delete();
        }catch(Exception e){
            fail("Unexpected Exception received: " + e.getMessage());
        }
        int newSize = Interview.data.size();
        assertEquals(previousSize, newSize);

    }

    @Test
    void save() {


        int previousSize = Discipline.data.size();
        Discipline discipline = new Discipline();
        discipline.save("disciplina 3",
                "disciplina-3",
                "Discipline 3");

        int newSize = Discipline.data.size();
        assertEquals(1, newSize - previousSize);
    }
}