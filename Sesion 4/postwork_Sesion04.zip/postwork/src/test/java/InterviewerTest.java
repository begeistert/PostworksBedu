

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.opentest4j.TestAbortedException;

import java.util.ArrayList;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;


public class InterviewerTest {
    static String existingInterviewerName = "First";
    static String existingInterviewerLastName = "User";
    static String existingInterviewerEmail =  "first@email.com";

    @BeforeEach
    public void setUp() throws Exception {
        Interviewer.data = new ArrayList<>();

        Interviewer.data.add(new Interviewer(
                existingInterviewerName,
                existingInterviewerLastName,
                existingInterviewerEmail,
                true
        ));
    }

    @Test
    public void add() {
        Interviewer interviewer = new Interviewer(
                "Test",
                "User",
                "any@email.com",
                true
        );

        // si invalid email throw Exception
        String regexPattern = "/^[a-zA-Z0-9.! #$%&'*+/=? ^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\. [a-zA-Z0-9-]+)*$";
        boolean validEmail = Pattern.compile(regexPattern).matcher(interviewer.email).matches();

        assertTrue(validEmail,"invalid email");

        interviewer.add();

        int expectedId = Interviewer.data.size();
        assertEquals(
                expectedId,
                interviewer.id,
                "Interviewer ID should be the new List's size"
        );
    }

    @Test
    public void delete() {
        Interviewer existingInterviewer = Interviewer.data.get(0);

        int expectedSize = Interviewer.data.size() - 1;

        try {
            existingInterviewer.delete();
        } catch (Exception e) {
            fail("Unexpected Exception received: " + e.getMessage());
        }

        int actualSize = Interviewer.data.size();

        assertEquals(
                expectedSize,
                actualSize,
                "List should be smaller"
        );
    }

    @Test
    public void testValidateIfNameLenghtIsLongerThan3() {
        Interviewer interviewer = new Interviewer(
                "nombre",
                "User",
                "any@email.com",
                true
        );

        // Regular expression to valid name should comply
        String regexPattern = "([a-zA-Z]){2}\\w+";
        boolean validName = Pattern.compile(regexPattern).matcher(interviewer.name).matches();

        assertTrue(validName,"Name should be longer than 3");

        interviewer.add();

        int expectedId = Interviewer.data.size();
        assertEquals(
                expectedId,
                interviewer.id,
                "Interviewer ID should be the new List's size"
        );
    }

    @Test
    public void testValidateIfLastNameLenghtIsLongerThan3() {
        Interviewer interviewer = new Interviewer(
                "abcd",
                "Ap",
                "any@email.com",
                true
        );

        // Regular expression to valid name should comply
        String regexPattern = "([a-zA-Z]){2}\\w+"; //"/([a-zA-Z]){3}";
        boolean validLastName = Pattern.compile(regexPattern).matcher(interviewer.lastName).matches();

        assertTrue(validLastName,"LastName should be longer than 3");

        interviewer.add();

        int expectedId = Interviewer.data.size();
        assertEquals(
                expectedId,
                interviewer.id,
                "Interviewer ID should be the new List's size"
        );
    }

}