package com.example.demo.data;

public interface SomeDataService {
    int[] retrieveAllData();
}
