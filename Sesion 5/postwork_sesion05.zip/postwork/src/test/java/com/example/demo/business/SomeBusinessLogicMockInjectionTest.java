package com.example.demo.business;

import com.example.demo.data.SomeDataService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SomeBusinessLogicMockInjectionTest {
    @InjectMocks
     SomeBusinessLogic business;

    @Mock
    SomeDataService dataServiceMock;

    @Test
    public void calculateSumUsingDataService_basic() {
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{1, 2, 3});
        int actual = business.calculateSumWithADataService();
        assertEquals(6, actual); // business.calculateSumWithADataService());
    }

    @Test
    public void calculateSumUsingDataService_empty() {
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{});
        int actual = business.calculateSumWithADataService();
        assertEquals(0, actual); // business.calculateSumWithADataService());
    }
    @Test
    public void calculateSumUsingDataService_singleElement() {
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{7});
        int actual = business.calculateSumWithADataService();
        assertEquals(7, actual); // business.calculateSumWithADataService());
    }


    /// postwork

    @Test
    public void calculateSubstractionUsingDataService_basic() {
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{1, 2, 3});
        int actual = business.calculateSubstractionWithADataService();
        assertEquals(-6, actual); // business.calculateSumWithADataService());
    }

    @Test
    public void calculateSubstractionUsingDataService_empty() {
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{});
        int actual = business.calculateSubstractionWithADataService();
        assertEquals(0, actual); // business.calculateSumWithADataService());
    }
    @Test
    public void calculateSubstractionUsingDataService_oneValue() {
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{7});
        int actual = business.calculateSubstractionWithADataService();
        assertEquals(-7, actual); // business.calculateSumWithADataService());
    }


    @Test
    public void calculateSumWithADataService_multipleReturnValues() {
        int firstExpected = 3;
        int secondExpected = 5;
        when(dataServiceMock.retrieveAllData())
                .thenReturn(new int[]{1,2})
                .thenReturn(new int[]{1,2,2});

        assertEquals(firstExpected, business.calculateSumWithADataService());
        assertEquals(secondExpected, business.calculateSumWithADataService());
        // business.calculateSumWithADataService());
    }

    @Test
    public void calculateSubstractionWithADataService_multipleReturnValues() {
        int firstExpected = -3;
        int secondExpected = -5;
        when(dataServiceMock.retrieveAllData())
                .thenReturn(new int[]{1,2})
                .thenReturn(new int[]{1,2,2})
                .thenReturn(new int[]{});

        assertEquals(firstExpected, business.calculateSubstractionWithADataService());
        assertEquals(secondExpected, business.calculateSubstractionWithADataService());
        assertEquals(0, business.calculateSubstractionWithADataService());
        // business.calculateSumWithADataService());
    }
}
