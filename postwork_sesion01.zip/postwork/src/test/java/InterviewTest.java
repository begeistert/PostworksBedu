import com.sun.java.swing.plaf.windows.WindowsTextAreaUI;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class InterviewTest {

    @BeforeEach
    void setUp() {
        Interviewer.data = new ArrayList<>();
        Candidate.data = new ArrayList<>();
        InterviewType.data = new ArrayList<>();
        Technology.data = new ArrayList<>();
        Discipline.data = new ArrayList<>();
        Interview.data = new ArrayList<>();

        Interviewer.data.add(new Interviewer ( "entrevistador 1",
                "apellido 1",
                "entrevistador1@email.com",
                true));

        Candidate.data.add( new Candidate ( "candidato 1",
                                            "apellido 1",
                                            "candidato@email.com",
                                                true));


        InterviewType.data.add( new InterviewType("tipo entrevista 1",
                "tipo-entrevista-1",
                "tipo de entrevista 1"));
        Technology.data.add( new Technology("Tecno 1",
                "tecnologia 1",
                "descipcion tecnologia 1"));
        Discipline.data.add(new Discipline("disciplina 1",
                "disciplina-1",
                "Disciplina 1"));
    }

    @Test
    void add() {
        Interviewer interviewer = new Interviewer( "entrevistador 2",
                "apellido  2",
                "interviewer2@email.com",
                true);

        Candidate candidate = new Candidate ( "candidato 2",
                "apellido 2",
                "candidato2@email.com",
                true);

        InterviewType interviewType = new InterviewType("tipo entrevista 2",
                "tipo-entrevista-2",
                "tipo de entrevista 2");
        Technology technology = new Technology("Tecno 2",
                "tecnologia 2",
                "descipcion tecnologia 2");
        Discipline discipline = new Discipline("disciplina 2",
                "disciplina-2",
                "Disciplina 2");

        int previousSize = Interview.data.size();
        Interview interview = new Interview(candidate,interviewer,interviewType,technology,discipline);
        interview.add();
        int newSize = Interview.data.size();

        assertEquals(1, newSize - previousSize);


    }

    @Test
    void delete() {
        Interviewer interviewer = new Interviewer( "entrevistador 3",
                "apellido  3",
                "interviewer2@email.com",
                true);

        Candidate candidate = new Candidate ( "candidato 3",
                "apellido 3",
                "candidato2@email.com",
                true);

        InterviewType interviewType = new InterviewType("tipo entrevista 3",
                "tipo-entrevista-3",
                "tipo de entrevista 3");
        Technology technology = new Technology("Tecno 3",
                "tecnologia 3",
                "descipcion tecnologia 3");
        Discipline discipline = new Discipline("disciplina 3",
                "disciplina-3",
                "Disciplina 3");

        int previousSize = Interview.data.size();
        Interview interview = new Interview(candidate,interviewer,interviewType,technology,discipline);
        interview.add();
        try {
            interview.delete();
        }catch(Exception e){
            fail("Unexpected Exception received: " + e.getMessage());
        }
        int newSize = Interview.data.size();
        assertEquals(previousSize, newSize);
    }

    @Test
    void save() {
        Interviewer interviewer = new Interviewer( "entrevistador 3",
                "apellido  3",
                "interviewer2@email.com",
                true);

        Candidate candidate = new Candidate ( "candidato 3",
                "apellido 3",
                "candidato2@email.com",
                true);

        InterviewType interviewType = new InterviewType("tipo entrevista 3",
                "tipo-entrevista-3",
                "tipo de entrevista 3");
        Technology technology = new Technology("Tecno 3",
                "tecnologia 3",
                "descipcion tecnologia 3");
        Discipline discipline = new Discipline("disciplina 3",
                "disciplina-3",
                "Disciplina 3");

        int previousSize = Interview.data.size();
        Interview interview = new Interview();
        interview.save(candidate,interviewer,interviewType,technology,discipline);

        int newSize = Interview.data.size();
        assertEquals(1, newSize - previousSize);
    }
}