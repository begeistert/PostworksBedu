import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class CandidateTest {

    static String existingCandidateName = "First";
    static String existingCandidateLastName = "User";
    static String existingCandidateEmail =  "first@email.com";

    @BeforeEach
    void setup(){

        Candidate.data = new ArrayList<>();

        Candidate.data.add(new Candidate(
                existingCandidateName,
                existingCandidateLastName,
                existingCandidateEmail,
                true
        ));
    }
    @Test
    void add() {
        Candidate candidate = new Candidate(
                "candidato 1",
                "apellido 1",
                "any@email.com",
                true
        );

        candidate.add();

        int expectedId = Candidate.data.size();
        assertEquals(
                expectedId,
                candidate.id,
                "Candidate ID should be the new List's size"
        );
    }

    @Test
    void delete() {
        Candidate existingCandidate = Candidate.data.get(0);

        int expectedSize = Candidate.data.size() - 1;

        try {
            existingCandidate.delete();
        } catch (Exception e) {
            fail("Unexpected Exception received: " + e.getMessage());
        }

        int actualSize = Candidate.data.size();

        assertEquals(
                expectedSize,
                actualSize,
                "List should be smaller"
        );
    }

    @Test
    void save(){
        int previousSize = Candidate.data.size();
        Candidate candidate = new Candidate();
        candidate.save("candidato 1",
                "apellido 1",
                "candidato@email.com",
                true);

        int newSize = Candidate.data.size();
        assertEquals(1, newSize - previousSize);
    }

    @Test
    void getByEmail() {
            Candidate candidate = new Candidate(
                    existingCandidateName,
                    existingCandidateLastName,
                    existingCandidateEmail,
                    true
            );
            candidate.add();
            //System.out.println(interviewer.toString());
            Candidate candidateReceived = Candidate.getByEmail("first@email.com");

            assertNotNull(candidateReceived, "Email no encontrado");
            assertEquals(candidate.email, candidateReceived.email);
    }
}