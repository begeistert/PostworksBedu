import java.io.*;
import java.util.ArrayList;

public class Interview {

    static ArrayList<Interview> data;

    int id;
    Candidate candidate;
    Interviewer interviewer;
    InterviewType interviewType;
    Technology technology;
    Discipline discipline;

    public Interview(){}

    public Interview(
            Candidate candidate,
            Interviewer interviewer,
            InterviewType interviewType,
            Technology technology,
            Discipline discipline
    ) {
        this.id = data != null ? data.size() + 1 : 1;
        this.candidate =  candidate;
        this.interviewer =  interviewer;
        this.interviewType =  interviewType;
        this.technology =  technology;
        this.discipline = discipline;

    }

    public Interview add(){
        data.add(this);
        Interview.saveDataToFile();
        return this;
    }



    public void delete() throws Exception{
        //InterviewType interviewType = InterviewType.datagetByEmail(this.email);

        //if (interviewType != null) {
        data.remove(this);
        this.saveDataToFile();
        //}
        //else
        //    throw new Exception("Interviewer not found");
    }

    public void save(
            Candidate candidate,
            Interviewer interviewer,
            InterviewType interviewType,
            Technology technology,
            Discipline discipline
    ) {
        try {
            this.delete();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }

        if (candidate!=null)
            this.candidate = candidate;

        if (interviewer!=null)
            this.interviewer = interviewer;

        if (interviewType != null)
            this.interviewType = interviewType;

        if (interviewType != null)
            this.technology = technology;

        if (discipline != null)
            this.discipline = discipline;

        data.add(this);
    }

    public static void saveDataToFile() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("./interview");
            ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);

            outputStream.writeObject(Interviewer.data);

            outputStream.close();
            fileOutputStream.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public static void loadDataFromFile() {
        try {
            FileInputStream fileInputStream = new FileInputStream("./interview");
            ObjectInputStream inputStream = new ObjectInputStream(fileInputStream);

            ArrayList<Interviewer> fileData = (ArrayList<Interviewer>) inputStream.readObject();

            Interviewer.data.clear();
            Interviewer.data.addAll(fileData);

            inputStream.close();
            fileInputStream.close();
        } catch (Exception e) {
            if (!e.getMessage().contains("No such file or directory"))
                e.printStackTrace();
        }
    }
}
