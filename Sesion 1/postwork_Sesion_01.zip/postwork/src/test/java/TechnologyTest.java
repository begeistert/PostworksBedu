import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class TechnologyTest {

    @BeforeEach
    void setUp() {
        Technology.data = new ArrayList<>();
        Technology.data.add(new Technology("Tecnologia 1",
                "Tecnologia-1",
                "Tecnologia 1"));
    }

    @Test
    void add() {
        Technology technology = new Technology("disciplina 2",
                "disciplina-2",
                "Disciplina 2");

        int previousSize = Technology.data.size();
        technology.add();
        int newSize = Technology.data.size();

        assertEquals(1, newSize - previousSize);

    }

    @Test
    void delete() {
        Technology technology = new Technology("disciplina 3",
                "disciplina-3",
                "Disciplina 3");

        int previousSize = Technology.data.size();
        technology.add();
        try {
            technology.delete();
        }catch(Exception e){
            fail("Unexpected Exception received: " + e.getMessage());
        }
        int newSize = Technology.data.size();
        assertEquals(previousSize, newSize);
    }

    @Test
    void save() {
        int previousSize = Technology.data.size();
        Technology technology = new Technology();
        technology.save("disciplina 3",
                "disciplina-3",
                "Discipline 3");

        int newSize = Technology.data.size();
        assertEquals(1, newSize - previousSize);
    }
}