package com.example.interviews;

import org.springframework.stereotype.Repository;

interface IInterviewerRepository{

    public void save(Interviewer interviewer);


}

@Repository
public class InterviewerRepository implements IInterviewerRepository {

    @Override
    public void save(Interviewer interviewer) {
            interviewer.add();

    }
}
