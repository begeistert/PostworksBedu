package com.example.interviews;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.regex.Pattern;

@SpringBootApplication
public class InterviewsApplication {
	public static void main(String[] args) {
		Interviewer.loadDataFromFile();
		SpringApplication.run(InterviewsApplication.class, args);
	}
}

@RestController
@RequestMapping("/api")
class MenuApp{

	@PostMapping("/add-interviewer")
	String addinterviewer(@RequestBody String newInterviewer){

		JSONObject data = new JSONObject(newInterviewer);
		JSONObject error = new JSONObject(); //"\"error\" : \"\"");
		//String regexPattern = "([a-zA-Z]{2})";
		String emailPattern = "([a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$)";
		Boolean isValidName = data.getString("name").length()>2 ? true: false;
		Boolean isValidLastName =data.getString("lastName").length() >2 ? true:false;
		Boolean isValidEmail = Pattern.compile(emailPattern).matcher(data.getString("email")).matches();

		if(!isValidName){
			error.put("error", "Invalid name");
			return error.toString();
		}
		if(!isValidLastName){
			error.put("error", "Invalid lastname");
			return error.toString();
		}
		if(!isValidEmail){
			error.put("error", "Invalid email");
			return error.toString();
		}

		Interviewer interviewer = new Interviewer(
				data.getString("name"),
				data.getString("lastName"),
				data.getString("email"),
				data.getBoolean("isActive")

		);
		interviewer.add();
		return interviewer.toJSON().toString();
	}

	@GetMapping("/interviewers")
	String addinterviewer(){

		JSONArray interviewers = new JSONArray();
		ArrayList<Interviewer> list = Interviewer.getAll();
		for (Interviewer interviewer : list){
			interviewers.put(interviewer.toJSON());
		}

		return interviewers.toString();
	}

}