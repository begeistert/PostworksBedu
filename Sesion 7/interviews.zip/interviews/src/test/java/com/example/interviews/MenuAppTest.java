package com.example.interviews;


import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;


import javax.swing.*;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class MenuAppTest {

    @Test
    void addinterviewer() {

        JSONObject data = new JSONObject();
        data.put ("name","admin1");
        data.put ("lastName", "System");
        data.put("email","admin@email.com");
        data.put("isActive", true);

        StringEntity entity = new StringEntity(data.toString(),
                ContentType.APPLICATION_JSON);

        CloseableHttpClient httpClient= HttpClientBuilder.create().build();
        HttpPost request = new HttpPost("http://localhost:8080/api/add-interviewer");
        request.setEntity(entity);
        try {
            HttpResponse response = (HttpResponse) httpClient.execute(request);

            HttpEntity responseEntity  =  response.getEntity();
            String responseString = EntityUtils.toString(responseEntity,"UTF-8");

            JSONObject actual = new JSONObject(responseString);

            assertEquals(data.getString("name")     ,actual.getString("name"));
            assertEquals(data.getString("lastName") ,actual.getString("lastName"));
            assertEquals(data.getString("email")    ,actual.getString("email"));
            assertEquals(data.getBoolean("isActive") ,actual.getBoolean("isActive"));

        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Test
    void addinterviewer_invalidName() {

        JSONObject data = new JSONObject();
        data.put ("name","ad");
        data.put ("lastName", "System");
        data.put("email","admin@email.com");
        data.put("isActive", true);

        JSONObject expected = new JSONObject();
        expected.put("error", "Invalid name");

        StringEntity entity = new StringEntity(data.toString(),
                ContentType.APPLICATION_JSON);

        CloseableHttpClient httpClient= HttpClientBuilder.create().build();
        HttpPost request = new HttpPost("http://localhost:8080/api/add-interviewer");
        request.setEntity(entity);
        try {
            HttpResponse response = (HttpResponse) httpClient.execute(request);

            HttpEntity responseEntity  =  response.getEntity();
            String responseString = EntityUtils.toString(responseEntity,"UTF-8");

            JSONObject actual = new JSONObject(responseString);

            assertEquals(expected.getString("error")     ,actual.getString("error"));



        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Test
    void addinterviewer_invalidLastName() {

        JSONObject data = new JSONObject();
        data.put ("name","admin");
        data.put ("lastName", "Sy");
        data.put("email","admin@email.com");
        data.put("isActive", true);

        JSONObject expected = new JSONObject();
        expected.put("error", "Invalid lastname");

        StringEntity entity = new StringEntity(data.toString(),
                ContentType.APPLICATION_JSON);

        CloseableHttpClient httpClient= HttpClientBuilder.create().build();
        HttpPost request = new HttpPost("http://localhost:8080/api/add-interviewer");
        request.setEntity(entity);
        try {
            HttpResponse response = (HttpResponse) httpClient.execute(request);

            HttpEntity responseEntity  =  response.getEntity();
            String responseString = EntityUtils.toString(responseEntity,"UTF-8");

            JSONObject actual = new JSONObject(responseString);

            assertEquals(expected.getString("error"),actual.getString("error"));


        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Test
    void addinterviewer_invalidEmail() {

        JSONObject data = new JSONObject();
        data.put ("name","admin");
        data.put ("lastName", "System");
        data.put("email","admin@email");
        data.put("isActive", true);

        JSONObject expected = new JSONObject();
        expected.put("error", "Invalid email");


        StringEntity entity = new StringEntity(data.toString(),
                ContentType.APPLICATION_JSON);

        CloseableHttpClient httpClient= HttpClientBuilder.create().build();
        HttpPost request = new HttpPost("http://localhost:8080/api/add-interviewer");
        request.setEntity(entity);
        try {
            HttpResponse response = (HttpResponse) httpClient.execute(request);

            HttpEntity responseEntity  =  response.getEntity();
            String responseString = EntityUtils.toString(responseEntity,"UTF-8");

            JSONObject actual = new JSONObject(responseString);

            assertEquals(expected.getString("error"),actual.getString("error"));

        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}