import java.util.ArrayList;
import java.util.List;

public class BubbleSort {

    public static int [] sorter(int[] unsorted) {

        // Refactorizando
        for (int i = 0; i < unsorted.length - 1; i++) {
            for (int j = 0; j < unsorted.length - i - 1; j++) {
                if (unsorted[j] > unsorted[j + 1]) {
                    int temp = unsorted[j];
                    unsorted[j] = unsorted[j + 1];
                    unsorted[j + 1] = temp;
                }
            }
        }
        return unsorted;
    }
}





















    /*
    public static int [] sorter(int[] unsorted) {

        // regresa arreglo si es nulo o tiene 1 elemento
        if(unsorted.length<=1) {return unsorted;}
        else
        {   //ordena con 2 elementos en el arreglo
            if(unsorted.length==2) {
                if (unsorted[0] > unsorted[1]) {
                    return new int[]{unsorted[1], unsorted[0]};
                }
            }
            else{
                //ordena con 3 o mas elementos
                for(int i=0; i < unsorted.length -1; i++) {
                    for(int j=0; j < unsorted.length -i - 1; j++){
                        if (unsorted[j] > unsorted[j + 1]) {
                            int temp = unsorted[j];
                            unsorted[j] = unsorted[j + 1];
                            unsorted[j + 1] = temp;
                        }
                    }
                }
            }
        }
        return unsorted;


    }
    */


















/*
for(int i=0; i < unsorted.length -1; i++) {
            for(int j=0; j < unsorted.length -i - 1; j++){
                if (unsorted[j] > unsorted[j + 1]) {
                    int temp = unsorted[j];
                    unsorted[j] = unsorted[j + 1];
                    unsorted[j + 1] = temp;
                }
            }
        }

 */