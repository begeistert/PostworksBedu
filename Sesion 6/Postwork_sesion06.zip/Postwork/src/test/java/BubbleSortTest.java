import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BubbleSortTest {

    @Test
    void bubbleSort_empty() {
        int[] unsorted = new int[]{};
        assertArrayEquals(new int[]{}, BubbleSort.sorter(unsorted));
    }

    @Test
    void bubbleSort_oneElement() {
        int[] unsorted = new int[]{1};
        assertArrayEquals(new int[]{1}, BubbleSort.sorter(unsorted));
    }

    @Test
    void bubbleSort_twoElement() {
        int[] unsorted = new int[]{2, 1};
        int[] result = BubbleSort.sorter(unsorted);
        assertArrayEquals(new int[]{1, 2}, result);
    }

    @Test
    void bubbleSort_treeElement() {
        int [] unsorted = new int[] {2,4,1};
        int [] result = BubbleSort.sorter(unsorted);
        assertArrayEquals(new int []{1,2,4}, result);
    }

    @Test
    void bubbleSort() {
        int [] unsorted = new int[] {2,4,1,5,7,3,8,9,6};
        int [] result = BubbleSort.sorter(unsorted);
        assertArrayEquals(new int []{1,2,3,4,5,6,7,8,9}, result);
    }
}

